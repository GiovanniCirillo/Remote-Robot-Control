package com.robot;

import jakarta.servlet.*;
import jakarta.servlet.annotation.*;
import jakarta.servlet.http.*;
import org.eclipse.paho.client.mqttv3.MqttException;
import java.util.UUID;
import com.robot.AppConfig;

@WebListener
public class AppContextListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {

        String broker = AppConfig.MQTT_BROKER_URL;

        try {
            MqttPublisher publisher =
                    new MqttPublisher(broker, "web-backend-" + UUID.randomUUID());
            sce.getServletContext().setAttribute("publisher", publisher);
            System.out.println("[MQTT] Connesso al broker: " + broker);
            
        } catch (MqttException e) {
            System.err.println("[MQTT] Broker non disponibile all'avvio: " + e.getMessage());
            sce.getServletContext().setAttribute("publisher", null); // esplicito
        }
    }
}
