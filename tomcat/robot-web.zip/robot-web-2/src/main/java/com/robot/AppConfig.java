package com.robot;

public final class AppConfig {
    public static final String MQTT_BROKER_URL = 
        System.getProperty("mqtt.brokerUrl", "tcp://172.26.0.225:1883");
    public static final String MQTT_TOPIC_CMD  = "cmd";

    private AppConfig() {}
}