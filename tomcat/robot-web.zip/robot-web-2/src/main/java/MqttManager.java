import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import com.robot.AppConfig;

@WebListener
public class MqttManager implements ServletContextListener {

    private MqttClient client;

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        try {
            String brokerUrl = AppConfig.MQTT_BROKER_URL;
            client = new MqttClient(brokerUrl, MqttClient.generateClientId(), new MemoryPersistence());
            MqttConnectOptions opts = new MqttConnectOptions();
            opts.setAutomaticReconnect(true);
            opts.setCleanSession(true);
            client.connect(opts);

            // Salva client nel context
            sce.getServletContext().setAttribute("mqttClient", client);
            System.out.println("[MqttManager] Connesso.");
            
        } catch (MqttException e) {
            System.err.println("[MqttManager] MQTT non disponibile: " + e.getMessage());
            sce.getServletContext().setAttribute("mqttClient", null);
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        try {
            if (client != null && client.isConnected()) {
                client.disconnect();
                client.close();
            }
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
}
