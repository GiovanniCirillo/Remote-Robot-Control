package com.robot;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import org.eclipse.paho.client.mqttv3.*;
import com.robot.AppConfig;

@WebServlet("/cmd")
public class CommandServlet extends HttpServlet {

    private static final String BROKER = AppConfig.MQTT_BROKER_URL;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String payload = "{\"cmd\":\"FORWARD\",\"speed\":200,\"durationMs\":1000}";

        try {
            MqttClient client = new MqttClient(BROKER, MqttClient.generateClientId());

            MqttConnectOptions options = new MqttConnectOptions();
            options.setAutomaticReconnect(true);
            options.setCleanSession(true);

            client.connect(options);

            MqttMessage message = new MqttMessage(payload.getBytes());
            message.setQos(0);

            client.publish("cmd", message);

            client.disconnect();

            resp.getWriter().println("Comando inviato!");

        } catch (MqttException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_SERVICE_UNAVAILABLE);
            resp.getWriter().println("{\"error\": \"MQTT non disponibile: "+ e.getMessage() + "\"}");
        }
    }
}