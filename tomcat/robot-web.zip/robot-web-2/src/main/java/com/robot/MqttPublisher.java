package com.robot;

import org.eclipse.paho.client.mqttv3.*;
import java.nio.charset.StandardCharsets;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class MqttPublisher {

    private final MqttClient client;

    public MqttPublisher(String brokerUrl, String clientId) throws MqttException {

        client = new MqttClient(brokerUrl, clientId, new MemoryPersistence());

        MqttConnectOptions opt = new MqttConnectOptions();
        opt.setAutomaticReconnect(true);
        opt.setCleanSession(true);

        client.connect(opt);
    }

    public synchronized void publish(String topic, String payload, int qos, boolean retained)
            throws MqttException {

        if (!client.isConnected()) {
            System.out.println("[MqttPublisher] Client disconnesso, tentativo di riconnessione...");
            MqttConnectOptions opt = new MqttConnectOptions();
            opt.setAutomaticReconnect(true);
            opt.setCleanSession(true);
            client.connect(opt);
        }

        MqttMessage msg = new MqttMessage(payload.getBytes(StandardCharsets.UTF_8));
        msg.setQos(qos);
        msg.setRetained(retained);

        client.publish(topic, msg);
    }
}
