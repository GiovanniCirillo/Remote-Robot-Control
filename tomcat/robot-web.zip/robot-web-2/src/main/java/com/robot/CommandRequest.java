package com.robot;

public class CommandRequest {
    public String cmd;
    public Integer speed;
    public Integer durationMs;
}
