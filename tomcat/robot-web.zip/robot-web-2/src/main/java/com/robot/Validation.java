package com.robot;

import java.util.Set;

public class Validation {

    private static final Set<String> ALLOWED =
            Set.of("FORWARD", "BACKWARD", "LEFT", "RIGHT", "STOP");

    public static void validate(CommandRequest r) {

        if (r == null)
            throw new IllegalArgumentException("Body mancante");

        if (r.cmd == null || !ALLOWED.contains(r.cmd))
            throw new IllegalArgumentException("cmd non valido");

        if (r.speed == null || r.speed < 0 || r.speed > 255)
            throw new IllegalArgumentException("speed deve essere 0..255");

        if (r.durationMs != null && r.durationMs < 0)
            throw new IllegalArgumentException("durationMs deve essere >= 0");
    }

    /*static void validate(CommandRequest cmdReq) {
        throw new UnsupportedOperationException("Not supported yet.");
    }*/
}
