function showStatus(el) {
    el.style.opacity = 1;
    setTimeout(() => { el.style.opacity = 0; }, 1500);
}

async function send_call(duration, robot_action) {
    let status_elements= document.getElementsByClassName("status_emoji");
    console.log(duration);
    try {
        let req = await fetch(
            "http://localhost:8080/robot-web/sendCmd", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(
                {
                    "cmd": robot_action ,
                    "speed": 200 ,
                    "durationMs": duration
                }),
                signal: AbortSignal.timeout(5000)
            }
        );
        if (req.ok) {
            showStatus(status_elements[0]);
        }
        else{
            console.log(req.status);
            showStatus(status_elements[1]);
        }
    } catch (e) {
        console.error(e);
        showStatus(status_elements[1]);
    }
}


let b = document.getElementsByClassName("move");
let inpBox = document.getElementById("Height");


for (let i = 0; i < b.length; i++) {
    b[i].addEventListener("click", () => send_call(inpBox.value, b[i].name));
}


inpBox.addEventListener("blur", function(){
    let intValue = parseInt(inpBox.value);
        if (!isNaN(intValue)) {
            if (inpBox.value < 1000) {
                inpBox.value = 1000;
            }
            else if (inpBox.value > 5000) {
                inpBox.value = 5000;
            }
        } else {inpBox.value = 1000;}
    });
