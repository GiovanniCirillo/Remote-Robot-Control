package com.example;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.BufferedReader;
import java.io.IOException;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import com.robot.AppConfig;

@WebServlet("/sendCmd")
public class MqttServlet extends HttpServlet {

    private static final String BROKER = AppConfig.MQTT_BROKER_URL;
    private static final String TOPIC = AppConfig.MQTT_TOPIC_CMD;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/plain");
        response.setCharacterEncoding("UTF-8");

        // Legge il body JSON inviato da JS
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = request.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
        }

        String payload = sb.toString().trim();

        if (payload.isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().println("Errore: body JSON mancante o vuoto");
            return;
        }

        try {
            // 1. crea client
            MqttClient client = new MqttClient(BROKER, MqttClient.generateClientId());

            // 2. connessione
            client.connect();

            // 3. messaggio con payload ricevuto da JS
            MqttMessage message = new MqttMessage(payload.getBytes("UTF-8"));
            message.setQos(0);

            // 4. publish
            client.publish(TOPIC, message);

            // 5. disconnessione
            client.disconnect();

            response.getWriter().println("OK - Messaggio inviato: " + payload);

        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().println("Errore: " + e.getMessage());
        }
    }
}